
<?php
$nume=$_POST['nume'];
$prenume=$_POST['parola'];
$xml = simplexml_load_file('data_users.xml');
$date=$xml->addChild('date');
$date->addChild('nume', $nume);
$date->addChild('parola', $prenume);
file_put_contents('data_users.xml', $xml->asXML());
 header('location:redirect.php');
?>

