<?php
       $xslDoc=new DOMDocument();
       $xslDoc->load("mathml_svg.xsl");
       
       $xmlDoc=new DOMDocument();
       $xmlDoc->load("mathml_svg.xml");
       // enable extension=php_xsl.dll in php.ini !!!
       $proc=new XSLTProcessor();
       $proc->importStylesheet($xslDoc);
       echo $proc->transformToXml($xmlDoc);
 ?>