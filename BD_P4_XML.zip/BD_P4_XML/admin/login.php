<?php
session_start();
$xml=simplexml_load_file("../register/data_users.xml") or die("Error: Cannot create object");

foreach($xml->children() as $data) {
if(($_POST['nume']==$data->nume) && ($_POST['parola']==$data->parola)){
    if (isset($_POST['rememberme'])) { 
    /* Set cookie to last 1 year */ 
    setcookie('username', $_POST['nume'], time()+60*60*24*365); 
    setcookie('password', md5($_POST['parola']), time()+60*60*24*365);
    } else { 
    /* Cookie expires when browser closes */ 
    setcookie('username', $_POST['nume'], false);
    setcookie('password', md5($_POST['parola']), false); 
    } 
    $_SESSION["nume"]=$_POST["nume"];
    header('location:user.php');
    exit();
}
}
foreach($xml->children() as $data) {
if(($_POST['nume']!=$data->nume) || ($_POST['parola']!=$data->parola)){
    
  header('location:../adminlogin.php');
}
}
?> 
