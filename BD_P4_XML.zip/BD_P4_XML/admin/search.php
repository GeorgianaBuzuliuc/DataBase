<!DOCTYPE html>

<html lang="en">
  <head>
    <title>UrbanRent</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="../images/icon.ico" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="../css/animate.css">
    
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <link rel="stylesheet" href="../css/magnific-popup.css">

    <link rel="stylesheet" href="../css/aos.css">

    <link rel="stylesheet" href="../css/ionicons.min.css">

    <link rel="stylesheet" href="../css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="../css/flaticon.css">
    <link rel="stylesheet" href="../css/icomoon.css">
    <link rel="stylesheet" href="../css/style.css">
  </head>
  
  <body>
   
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      
	      <a href='logout.php' class='btn btn-primary py-2 mr-1'>Logout</a>
                            <svg height="100" width="180">
                <defs>
                  <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%"
                    style="stop-color:rgb(255,0,0);stop-opacity:1" />
                    <stop offset="100%"
                    style="stop-color:rgb(0,0,0);stop-opacity:1" />
                  </linearGradient>
                </defs>
                    <ellipse cx="90" cy="60" rx="85" ry="30" fill="url(#grad1)" />
                <text fill="#ffffff" font-size="30" font-family="Arial"
                x="48" y="70"><?php
                  session_start();
                  if(isset($_SESSION["nume"])){
                      echo $_SESSION["nume"];
                  }else{
                      header("Location:../adminlogin.php");
                  }
                  ?></text>
              </svg>
                
               <a class="navbar-brand" href="../index.php" ><span style="color:black">Urban</span><span>Rent</span></a> 
	  </nav>
    <!-- END nav -->
    <div class="row no-gutters slider-text justify-content-start align-items-center justify-content-center">
      <section class="ftco-section ftco-cart">
			<div class="container">
				<?php
       $params=array('title'=>$_POST['nume']);
       if(!empty($params)){
             $xslDoc=new DOMDocument();
       $xslDoc->load("search.xsl");
       
       $xmlDoc=new DOMDocument();
       $xmlDoc->load("data.xml");

      $proc=new XSLTProcessor();
       $proc->importStylesheet($xslDoc);
       foreach($params as $title=>$val)
           $proc->setParameter('',$title,$val);
       
        echo $proc->transformToXml($xmlDoc);
       }else{
            echo "No results. Please try again!";
       }
     
        
?>
          <a href="user.php"  class="btn btn-primary">Back</a>                 
                                                    </section>                     </div>
                                       

                                    
 <!-- SVG pt loader-->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>

  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery.easing.1.3.js"></script>
  <script src="../js/jquery.waypoints.min.js"></script>
  <script src="../js/jquery.stellar.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.magnific-popup.min.js"></script>
  <script src="../js/aos.js"></script>
  <script src="../js/jquery.animateNumber.min.js"></script>
  <script src="../js/bootstrap-datepicker.js"></script>
  <script src="../js/jquery.timepicker.min.js"></script>
  <script src="../js/scrollax.min.js"></script>
  <script src="../js/main.js"></script>
  <script language="JavaScript1.2">
function disabletextselect(i){
return false;
}
function renabletextselect(){
return true;
}
//if IE4+
document.onselectstart=new Function ("return false");
//if NS6+
if (window.sidebar){
document.onmousedown=disabletextselect;
document.onclick=renabletextselect;
}
</script>
  </body>
</html>
