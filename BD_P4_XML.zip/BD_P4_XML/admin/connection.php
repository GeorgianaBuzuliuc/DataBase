<?php
$con=mysqli_connect('localhost', 'root', '', 'images3') or die("Failed to connect: ". mysqli_error($con));
?>


