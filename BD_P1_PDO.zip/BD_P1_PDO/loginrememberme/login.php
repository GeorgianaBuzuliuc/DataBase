<?php 
$user = '111';
$pass = '222'; 
if((isset($_POST['username'])) && (isset($_POST['password']))) {
 if (($_POST['username'] == $user) && ($_POST['password'] == $pass)) { 
if (isset($_POST['rememberme'])) { 
/* Set cookie to last 1 year */ 
setcookie('username', $_POST['username'], time()+60*60*24*365); 
setcookie('password', md5($_POST['password']), time()+60*60*24*365);
 } else { 
/* Cookie expires when browser closes */ 
setcookie('username', $_POST['username'], false);
 setcookie('password', md5($_POST['password']), false); 
 } 
	header("Location:logged.php");
} 
else { echo '<canvas id="myCanvas" width="450" height="100" style="border:1px solid red;"></canvas>'; 
} 
} else {
    echo 'You must supply a username and password.';
    }
 ?> 
<script>
var c = document.getElementById("myCanvas");
var ctx = c.getContext("2d");
ctx.font = "30px Arial";
ctx.fillText("Invalid Username or Password",10,50);
</script>