
<?php
include 'connection.php';
$sqltriggerdrop= "DROP TRIGGER IF EXISTS after_delete";
$sqltrigger="CREATE TRIGGER after_delete AFTER DELETE ON images_out FOR EACH ROW
BEGIN
INSERT INTO images_update(name,status,edtime) VALUES(OLD.title, 'DELETED',NOW());
END;";

$stmttriggerdrop=$con->prepare($sqltriggerdrop);
$stmttrigger=$con->prepare($sqltrigger);

$stmttriggerdrop->execute();
$stmttrigger->execute();


$sql1="DROP PROCEDURE IF EXISTS deleteImage";
$sql2="CREATE PROCEDURE deleteImage( 
 IN numar int
) 
BEGIN 
      DELETE FROM images_out WHERE id=numar;
END;";
$stmt1=$con->prepare($sql1);
$stmt2=$con->prepare($sql2);
$stmt1->execute();
$stmt2->execute();
$numar = $_GET['id'];
$sql="CALL deleteImage('{$numar}')";


$current_id = $con->query($sql) or die("<b>Error:</b> Problem on Image Delete<br/>" . mysqli_error($con));
                        if(isset($current_id)) {
			header('Location:user.php');
                        }


?>