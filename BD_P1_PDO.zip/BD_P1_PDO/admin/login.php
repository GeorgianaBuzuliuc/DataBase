<?php
session_start();
$user="admin";
$pass="admin";
$message="";
$correctsum = $_POST['correctsum'];
if((!(empty($_POST["username"])))||(!empty($_POST["password"]))||(!empty($_POST["captcha"])))
{
    if(($_POST["username"]==$user)&&($_POST["password"]==$pass)){
        if(!isset($_POST['captcha'])){
            echo 'Please enter the captcha!<br/>';
        }
        elseif($_POST['captcha']!=$_POST['correctsum']){ 
            echo'The sum is not correct! Please add again.<br/>'; 
        }
        else{ 
            $_SESSION["user_name"]=$_POST["username"];
            header("Location:user.php");
            }
        }
    else {
        echo '<canvas id="myCanvas" width="510" height="100" style="border:1px solid red;"></canvas>'; 
    }
} 
else {
    header("Location:../index.php");
}
?>
<script>
var c = document.getElementById("myCanvas");
var ctx = c.getContext("2d");
ctx.font = "30px Arial";
ctx.fillText("Invalid Username/Password/Captcha",10,50);
</script>