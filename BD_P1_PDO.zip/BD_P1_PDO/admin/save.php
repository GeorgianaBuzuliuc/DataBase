<?php
require_once "connection.php";
$msg="";
if(isset($_POST['upload'])){
$target="./images/".basename($_FILES['image']['name']);
   $text=$_POST['text'];
 
   $sql1="DROP PROCEDURE IF EXISTS insertImage";
   $sql2="CREATE PROCEDURE insertImage(
      IN strTitle varchar(100),
      In strImage varchar(100)
   )
    BEGIN 
      INSERT INTO images_out (title,image) VALUES (strTitle,strImage);
   END;";
    $stmt1=$con->prepare($sql1);
    $stmt2=$con->prepare($sql2);
    $stmt1->execute();
    $stmt2->execute();
   $sqlc="CALL insertImage('{$text}','{$target}')";
   $sqltriggerdrop= "DROP TRIGGER IF EXISTS after_insert";
   $sqlT="CREATE TRIGGER after_insert AFTER INSERT ON images_out "
           . "FOR EACH ROW BEGIN INSERT INTO images_update(name,status,edtime) VALUES (NEW.title,'INSERTED',NOW()); END;";
  $stmttriggerdrop=$con->prepare($sqltriggerdrop);
  $stmttriggerdrop->execute();
   $stmt=$con->prepare($sqlT);
   $stmt->execute();
   $q=$con->query($sqlc);
   if ($q) {
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            header('location:user.php');
        } else {
             $msg = "Eroare";
        }
    }
}
echo $msg;
